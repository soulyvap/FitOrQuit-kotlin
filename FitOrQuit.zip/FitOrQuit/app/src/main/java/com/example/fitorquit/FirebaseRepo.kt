package com.example.fitorquit

import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.UploadTask
import java.io.Serializable

object FirebaseRepo {
    private const val TAG = "FirebaseRepo"
    val currentUser get() = FirebaseAuth.getInstance().currentUser

    fun createUser(user: User): Task<Void> {
        val uid = FirebaseAuth.getInstance().currentUser!!.uid
        val db = FirebaseFirestore.getInstance()
        val userRef = db.collection("users")
        val docRef = userRef.document(uid)
        return docRef.set(user)
    }

    fun checkUserDoc(): DocumentReference {
        val db = FirebaseFirestore.getInstance()
        val userRef = db.collection("users")
        return userRef.document(currentUser!!.uid)
    }

    fun addPic(uri: Uri, path: String): UploadTask {
        val storage = FirebaseStorage.getInstance()
        val ref = storage.reference.child(path)
        return ref.putFile(uri)
    }

    fun getPic(path: String): StorageReference {
        val storage = FirebaseStorage.getInstance()
        return storage.reference.child(path)
    }

    fun checkUsername(username: String): Query {
        val db = FirebaseFirestore.getInstance()
        val userRef = db.collection("users")
        return userRef.whereEqualTo("username", username)
    }

    fun logout() {
        FirebaseAuth.getInstance().signOut()
    }
}

class User(val name: String, val email: String, val username: String, val country: String, val birthdate: String): Serializable